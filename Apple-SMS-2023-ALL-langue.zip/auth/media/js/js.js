jQuery(function ($) {
    $('.apl-inpt')
        .on("focus", function () {
            $(this).parent().addClass('focus')
            $(this).addClass('top-input')
        })
        .on("blur", function () {
            if ($(this).val() === '') {
                $(this).removeClass('top-input')
                $(this).parent().removeClass('focus')
            }
        });

    $('.apl-inpt').each(function(){
        if($(this).val().length > 0) {
            $(this).parent().addClass('focus')
            $(this).addClass('top-input')
        }
    });

    $('.sign-in-btn-1').click(function () {
        $('.password-groupe').removeClass('hidden')
        $(this).addClass('hidden')

        $(this).parents('.auth-cnt').addClass('password-shown')
    })

    let tfaInputs = $('.sms-area input')

    tfaInputs.map(function (idx, item) {
        $(item).on("keydown", function (e) {
            const keyCode = e.keyCode
            const nextidx = idx + 1
            const previdx = idx - 1

            if (keyCode == 8) {
                if ($(this).val().trim() === '' && previdx >= 0) {
                    tfaInputs[previdx].focus()
                }
            }
            else {
                if ($(this).val().trim() !== '') {
                    if (nextidx < tfaInputs.length) {
                        tfaInputs[nextidx].focus()
                    } else {
                        $(this).blur()
                    }
                }
            }
        })
    })

    $('.tow-factory input').map((index, item) => {
        $(item).on('focus', function () {
            if (index > 0 && $($('input')[index - 1]).val() == '') {
                $($('input')[index - 1]).focus()
            }
        })
    })
})